#!/bin/bash

cd AWS || exit

# Run Terraform commands
terraform init
terraform plan
terraform apply -auto-approve


#install saral app
cd ../helm || exit

helm install saral-ingress ./saral-ingress-chart

helm install saral-ingress ./saral-ingress-chart
